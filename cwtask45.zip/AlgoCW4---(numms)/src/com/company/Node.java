package com.company;

import java.util.ArrayList;
import java.util.List;

public class Node {
    int data;


    Node(int data){
        this.data = data;

    }


}
